<?php
// Merge these routes into routes/api.php. Ensure middleware aliases are registered
// in bootstrap/app.php (Laravel 11+) or app/Http/Kernel.php (older Laravel).

use App\Http\Controllers\Api\Admin\DashboardController;
use App\Http\Controllers\Api\Admin\UserAdminController;
use App\Http\Controllers\Api\Admin\CreditAdminController;
use App\Http\Controllers\Api\Admin\UniverseMessageAdminController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth:sanctum', 'admin'])->prefix('admin')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'summary']);
    Route::get('/users', [UserAdminController::class, 'index']);
    Route::patch('/users/{user}/status', [UserAdminController::class, 'setStatus']);
    Route::post('/users/{user}/credits/adjust', [CreditAdminController::class, 'adjust']);

    Route::apiResource('/universe-messages', UniverseMessageAdminController::class)
        ->only(['index', 'store', 'update', 'destroy']);
});
