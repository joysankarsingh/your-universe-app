# Your Universe — Milestone 6
## Admin Panel + Super Admin Dashboard (Laravel integration pack)

This is an integration pack, not a complete installed/deployed Laravel application.
It assumes the backend from Milestones 3–5 and Laravel authentication are already integrated.

## Included
- Admin dashboard summary API
- User listing, search and status controls
- Credit adjustment endpoint with transaction ledger entry
- Daily Universe Message CRUD API
- Multilingual content records (bn, hi, en)
- AI usage/cost reporting structure
- Admin role middleware and audit log
- Basic Blade dashboard shell and integration checklist

## Before use
1. Merge migrations, models, controllers, middleware and routes into the existing Laravel project.
2. Confirm your existing User, CreditWallet, CreditTransaction and ChatMessage schemas. Adjust field names where needed.
3. Add `is_admin` / `is_super_admin` authorization safely. Never let a user promote themselves.
4. Configure admin login with strong passwords, MFA if available, HTTPS, rate limiting and audit logging.
5. Do not expose API keys, provider secrets, raw prompts or sensitive birth data in dashboard tables.
6. Revenue figures in this pack are based on verified purchase ledger records, not client-side payment callbacks.
7. Add Google Play Developer API verification and Real-Time Developer Notifications separately before launch.

## Important
- The API routes are examples to merge, not a drop-in guarantee.
- The dashboard uses sample Blade markup; connect it to the routes and your chosen admin auth guard.
- Revenue and AI cost calculations require verified ledger/usage records to be populated.
- No deployment, live database connection, security audit or runtime test has been performed.
