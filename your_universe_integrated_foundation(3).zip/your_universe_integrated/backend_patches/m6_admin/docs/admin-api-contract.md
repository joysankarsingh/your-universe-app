# Admin API contract

All endpoints require authenticated admin access.

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/admin/dashboard` | User, revenue and AI usage summary |
| GET | `/api/admin/users?q=` | Paginated user search |
| PATCH | `/api/admin/users/{id}/status` | Activate/suspend account |
| POST | `/api/admin/users/{id}/credits/adjust` | Manual credit adjustment with audit trail |
| GET/POST | `/api/admin/universe-messages` | List/create message |
| PUT/PATCH/DELETE | `/api/admin/universe-messages/{id}` | Update/delete message |

Credit adjustment JSON:
```json
{
  "amount": 25,
  "reason": "Customer support correction"
}
```

Universe message JSON:
```json
{
  "language": "bn",
  "title": "আজকের Universe Message",
  "body": "আপনার জন্য আজকের বার্তা...",
  "category": "daily",
  "publish_date": "2026-11-06",
  "is_published": true
}
```

## Data dependencies
- `users`: `is_admin`, `is_super_admin`, `account_status`
- `credit_wallets`: `user_id`, `balance`
- `credit_transactions`: `user_id`, `amount`, `type`, `description`, `reference`
- `subscriptions`: `user_id`, `status`, `ends_at`
- `verified_purchases`: `status`, `gross_amount`, `created_at`
- `ai_usage_logs`: created by this pack

Adjust names to match the merged Milestone 3–5 schema. Do not create a fake revenue table merely to make dashboard totals appear.
