# Admin security checklist

- Create the first super-admin through a one-time deployment command or database seeder; never through public registration.
- Require strong password, MFA where possible, HTTPS and login rate limits.
- Use least-privilege admin roles. Content editors should not be able to grant super-admin rights.
- Log all credit changes, account suspensions, content edits and role changes.
- Require a reason for manual wallet adjustments.
- Never display full birth details, private chat transcripts, API keys or payment tokens in ordinary admin screens.
- Keep purchase verification and refund processing server-side.
- Add CSRF protection for browser sessions and authorization checks on every admin route.
- Back up database and test restore procedures.
- Add data export/deletion workflows and publish an accurate privacy policy.
- Review India and target-market privacy, consumer, tax and Google Play requirements before launch.
