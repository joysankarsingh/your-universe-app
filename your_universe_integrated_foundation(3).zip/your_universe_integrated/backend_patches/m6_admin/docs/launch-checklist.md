# Milestone 6 integration checklist

- [ ] Confirm Laravel version and existing model/table names.
- [ ] Merge migrations and run them on staging first.
- [ ] Register `admin` and `superadmin` middleware aliases.
- [ ] Add `subscriptions()` relationship to User if not already present.
- [ ] Create first super-admin securely.
- [ ] Merge API routes and protect them with Sanctum.
- [ ] Confirm verified purchase ledger schema before displaying revenue.
- [ ] Write AI usage logs after each successful/failed provider request.
- [ ] Test admin access denial for ordinary users.
- [ ] Test wallet adjustment under concurrent requests.
- [ ] Test Bengali, Hindi and English content publishing.
- [ ] Perform security review and backup before production.
