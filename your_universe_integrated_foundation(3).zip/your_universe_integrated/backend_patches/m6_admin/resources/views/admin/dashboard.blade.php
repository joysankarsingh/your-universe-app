<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Your Universe — Admin</title>
    <style>
        body{margin:0;background:#100b24;color:#f7f0dc;font:15px system-ui}
        .wrap{max-width:1100px;margin:40px auto;padding:20px}
        header{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #9b7b36;padding-bottom:18px}
        h1{font-size:24px;margin:0}.muted{color:#b7accb}
        .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin-top:24px}
        .card{background:#1c1437;border:1px solid #9b7b36;border-radius:14px;padding:18px}
        .value{font-size:28px;font-weight:700;margin-top:10px}
        .note{margin-top:25px;color:#c9bfd8;line-height:1.6}
    </style>
</head>
<body>
<div class="wrap">
    <header>
        <div><h1>Your Universe — Admin Dashboard</h1><div class="muted">Operations overview</div></div>
        <div class="muted">Secure Admin Area</div>
    </header>
    <section class="grid">
        <div class="card">Total Users<div class="value" id="users">—</div></div>
        <div class="card">Premium Users<div class="value" id="premium">—</div></div>
        <div class="card">Monthly Gross (INR)<div class="value" id="revenue">—</div></div>
        <div class="card">AI Cost (USD)<div class="value" id="cost">—</div></div>
        <div class="card">AI Requests This Month<div class="value" id="requests">—</div></div>
    </section>
    <p class="note">Connect this view to <code>/api/admin/dashboard</code> using your authenticated admin session.
    Do not put API secrets in frontend JavaScript. Restrict access to authorized admins only.</p>
</div>
</body>
</html>
