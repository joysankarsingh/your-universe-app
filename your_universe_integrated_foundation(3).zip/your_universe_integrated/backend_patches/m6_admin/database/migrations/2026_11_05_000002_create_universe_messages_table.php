<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('universe_messages', function (Blueprint $table) {
            $table->id();
            $table->string('language', 5)->index(); // bn, hi, en
            $table->string('title');
            $table->longText('body');
            $table->string('category', 60)->default('daily');
            $table->date('publish_date')->nullable()->index();
            $table->boolean('is_published')->default(false)->index();
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('universe_messages');
    }
};
