<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AiUsageLog extends Model
{
    protected $fillable = [
        'user_id', 'feature', 'provider', 'model',
        'input_tokens', 'output_tokens', 'estimated_cost_usd',
        'request_status'
    ];

    protected $casts = [
        'estimated_cost_usd' => 'decimal:6',
    ];
}
