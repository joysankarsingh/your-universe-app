<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UniverseMessage extends Model
{
    protected $fillable = [
        'language', 'title', 'body', 'category',
        'publish_date', 'is_published', 'created_by'
    ];

    protected $casts = [
        'publish_date' => 'date',
        'is_published' => 'boolean',
    ];
}
