<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = $request->user();

        if (!$user || (!$user->is_admin && !$user->is_super_admin)) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        if (($user->account_status ?? 'active') !== 'active') {
            return response()->json(['message' => 'Account disabled'], 403);
        }

        return $next($request);
    }
}
