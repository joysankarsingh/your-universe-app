<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class UserAdminController extends Controller
{
    public function index(Request $request)
    {
        $query = User::query()->select([
            'id', 'name', 'email', 'account_status', 'is_admin',
            'is_super_admin', 'created_at'
        ]);

        if ($request->filled('q')) {
            $term = trim($request->string('q'));
            $query->where(function ($q) use ($term) {
                $q->where('name', 'like', "%{$term}%")
                  ->orWhere('email', 'like', "%{$term}%");
            });
        }

        return $query->latest()->paginate(25);
    }

    public function setStatus(Request $request, User $user)
    {
        abort_if($user->is_super_admin, 403, 'Cannot change super admin status.');

        $data = $request->validate([
            'account_status' => ['required', Rule::in(['active', 'suspended'])],
        ]);

        $user->account_status = $data['account_status'];
        $user->save();

        return response()->json(['message' => 'User status updated.']);
    }
}
