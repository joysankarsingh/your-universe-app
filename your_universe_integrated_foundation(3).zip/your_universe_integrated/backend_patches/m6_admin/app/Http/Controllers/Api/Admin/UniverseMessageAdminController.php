<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\UniverseMessage;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class UniverseMessageAdminController extends Controller
{
    public function index()
    {
        return UniverseMessage::latest()->paginate(25);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'language' => ['required', Rule::in(['bn', 'hi', 'en'])],
            'title' => ['required', 'string', 'max:255'],
            'body' => ['required', 'string', 'max:30000'],
            'category' => ['required', 'string', 'max:60'],
            'publish_date' => ['nullable', 'date'],
            'is_published' => ['required', 'boolean'],
        ]);

        $data['created_by'] = $request->user()->id;
        return response()->json(UniverseMessage::create($data), 201);
    }

    public function update(Request $request, UniverseMessage $message)
    {
        $data = $request->validate([
            'language' => ['sometimes', Rule::in(['bn', 'hi', 'en'])],
            'title' => ['sometimes', 'string', 'max:255'],
            'body' => ['sometimes', 'string', 'max:30000'],
            'category' => ['sometimes', 'string', 'max:60'],
            'publish_date' => ['nullable', 'date'],
            'is_published' => ['sometimes', 'boolean'],
        ]);

        $message->update($data);
        return response()->json($message);
    }

    public function destroy(UniverseMessage $message)
    {
        $message->delete();
        return response()->json(['message' => 'Message deleted.']);
    }
}
