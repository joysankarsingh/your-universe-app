<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\CreditWallet;
use App\Models\CreditTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CreditAdminController extends Controller
{
    public function adjust(Request $request, User $user)
    {
        $data = $request->validate([
            'amount' => ['required', 'integer', 'between:-10000,10000', 'not_in:0'],
            'reason' => ['required', 'string', 'max:250'],
        ]);

        return DB::transaction(function () use ($request, $user, $data) {
            $wallet = CreditWallet::where('user_id', $user->id)->lockForUpdate()->firstOrFail();
            $newBalance = (int) $wallet->balance + (int) $data['amount'];

            if ($newBalance < 0) {
                throw ValidationException::withMessages([
                    'amount' => 'Adjustment would make wallet balance negative.'
                ]);
            }

            $wallet->balance = $newBalance;
            $wallet->save();

            CreditTransaction::create([
                'user_id' => $user->id,
                'amount' => (int) $data['amount'],
                'type' => 'admin_adjustment',
                'description' => $data['reason'],
                'reference' => 'admin:' . $request->user()->id . ':' . now()->timestamp,
            ]);

            DB::table('admin_audit_logs')->insert([
                'admin_id' => $request->user()->id,
                'action' => 'credit_adjustment',
                'target_type' => 'user',
                'target_id' => $user->id,
                'details' => json_encode(['amount' => $data['amount'], 'reason' => $data['reason']]),
                'ip_address' => $request->ip(),
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            return response()->json(['balance' => $newBalance]);
        });
    }
}
