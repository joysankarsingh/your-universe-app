<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\AiUsageLog;
use App\Models\CreditTransaction;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function summary(Request $request)
    {
        $from = Carbon::now()->startOfMonth();
        $to = Carbon::now()->endOfMonth();

        // Revenue is only reliable when verified purchases are written to a
        // dedicated purchase ledger. This pack intentionally does not guess
        // revenue from wallet top-ups or client callbacks.
        $revenue = DB::table('verified_purchases')
            ->where('status', 'verified')
            ->whereBetween('created_at', [$from, $to])
            ->sum('gross_amount');

        $usage = AiUsageLog::whereBetween('created_at', [$from, $to]);
        return response()->json([
            'users' => [
                'total' => User::count(),
                'active' => User::where('account_status', 'active')->count(),
                'premium' => User::whereHas('subscriptions', function ($q) {
                    $q->where('status', 'active')->where('ends_at', '>', now());
                })->count(),
                'new_this_month' => User::whereBetween('created_at', [$from, $to])->count(),
            ],
            'revenue' => [
                'month_gross' => round((float) $revenue, 2),
                'currency' => 'INR',
                'note' => 'Requires verified_purchases table and server-side purchase verification.',
            ],
            'ai' => [
                'requests' => (clone $usage)->count(),
                'input_tokens' => (clone $usage)->sum('input_tokens'),
                'output_tokens' => (clone $usage)->sum('output_tokens'),
                'estimated_cost_usd' => round((float) (clone $usage)->sum('estimated_cost_usd'), 4),
                'failed_requests' => (clone $usage)->where('request_status', 'failed')->count(),
            ],
        ]);
    }
}
