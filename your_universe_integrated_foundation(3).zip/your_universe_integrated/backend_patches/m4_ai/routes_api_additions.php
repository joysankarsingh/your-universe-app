// Add inside the existing auth:sanctum route group in routes/api.php:
use App\Http\Controllers\Api\ReadingInterpretController;

Route::post('/readings/{reading}/interpret', ReadingInterpretController::class);
