<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Reading;
use App\Services\TarotInterpreter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

class ReadingInterpretController extends Controller
{
    public function __invoke(Request $request, Reading $reading, TarotInterpreter $interpreter)
    {
        abort_unless($reading->user_id === $request->user()->id, 404);

        $birth = $request->user()->birthProfile;
        $profile = [
            'name' => $request->user()->name,
            'birth_date' => optional($birth?->birth_date)->format('Y-m-d'),
            'birth_time' => $birth?->birth_time,
            'birth_place' => $birth?->birth_place,
        ];

        try {
            $interpretation = $interpreter->interpret($reading, $profile);
            $reading->update(['interpretation' => $interpretation, 'status' => 'completed']);
            return response()->json($reading->fresh());
        } catch (Throwable $e) {
            Log::warning('Tarot interpretation failed', ['reading_id' => $reading->id, 'error' => $e->getMessage()]);
            return response()->json(['message' => 'Reading could not be generated right now. Please try again.'], 503);
        }
    }
}
