<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ChatThread;
use App\Services\CosmicPrompt;
use App\Services\OpenAiResponses;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

class ChatController extends Controller
{
    public function __construct(
        private OpenAiResponses $openAi,
        private CosmicPrompt $prompt
    ) {}

    public function threads(Request $request)
    {
        return response()->json(
            ChatThread::where('user_id', $request->user()->id)->latest()->paginate(20)
        );
    }

    public function createThread(Request $request)
    {
        $data = $request->validate([
            'title' => ['nullable','string','max:120'],
            'language' => ['nullable','in:bn,hi,en'],
        ]);
        $thread = ChatThread::create($data + [
            'user_id' => $request->user()->id,
            'language' => $data['language'] ?? $request->user()->preferred_language ?? 'en',
        ]);
        return response()->json($thread, 201);
    }

    public function messages(Request $request, ChatThread $thread)
    {
        abort_unless($thread->user_id === $request->user()->id, 404);
        return response()->json($thread->messages()->latest()->paginate(50));
    }

    public function storeMessage(Request $request, ChatThread $thread)
    {
        abort_unless($thread->user_id === $request->user()->id, 404);
        $data = $request->validate(['content' => ['required','string','max:8000']]);

        // Save the user's message first. If AI is unavailable, the user message is not lost.
        $userMessage = $thread->messages()->create([
            'role' => 'user',
            'content' => trim($data['content']),
        ]);

        $limit = max(4, min(30, (int) config('services.openai.max_context_messages', 16)));
        $history = $thread->messages()
            ->latest('id')
            ->take($limit)
            ->get()
            ->reverse()
            ->map(fn ($m) => ['role' => $m->role, 'content' => $m->content])
            ->values()
            ->all();

        $user = $request->user();
        $birth = $user->birthProfile;
        $profile = [
            'name' => $user->name,
            'birth_date' => optional($birth?->birth_date)->format('Y-m-d'),
            'birth_time' => $birth?->birth_time,
            'birth_place' => $birth?->birth_place,
        ];

        try {
            $instructions = $this->prompt->build($profile, $thread->language ?: 'en');
            $result = $this->openAi->generate($instructions, $history);

            $assistantMessage = $thread->messages()->create([
                'role' => 'assistant',
                'content' => $result['text'],
                'metadata' => [
                    'provider' => 'openai_responses',
                    'response_id' => $result['response_id'],
                    'usage' => $result['usage'],
                ],
            ]);

            $thread->touch();

            return response()->json([
                'user_message' => $userMessage,
                'assistant_message' => $assistantMessage,
                'ai_status' => 'completed',
            ], 201);
        } catch (Throwable $e) {
            Log::warning('Cosmic Chat generation failed', [
                'thread_id' => $thread->id,
                'user_id' => $user->id,
                'error' => $e->getMessage(),
            ]);

            return response()->json([
                'user_message' => $userMessage,
                'ai_status' => 'temporarily_unavailable',
                'message' => 'Your message was saved, but the AI could not reply just now. Please try again shortly.',
            ], 503);
        }
    }
}
