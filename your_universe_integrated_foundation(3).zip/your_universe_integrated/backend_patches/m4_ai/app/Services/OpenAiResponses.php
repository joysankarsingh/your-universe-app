<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use RuntimeException;

class OpenAiResponses
{
    public function generate(string $instructions, array $messages): array
    {
        $key = config('services.openai.key');
        if (!$key) {
            throw new RuntimeException('OpenAI API key is not configured.');
        }

        $input = [];
        foreach ($messages as $message) {
            $role = in_array($message['role'] ?? '', ['assistant', 'user'], true)
                ? $message['role'] : 'user';
            $input[] = [
                'role' => $role,
                'content' => [[
                    'type' => 'input_text',
                    'text' => (string) ($message['content'] ?? ''),
                ]],
            ];
        }

        $response = Http::withToken($key)
            ->acceptJson()
            ->asJson()
            ->timeout(config('services.openai.timeout', 45))
            ->post('https://api.openai.com/v1/responses', [
                'model' => config('services.openai.model', 'gpt-5.5'),
                'instructions' => $instructions,
                'input' => $input,
                'store' => false,
                'max_output_tokens' => 900,
            ]);

        if (!$response->successful()) {
            report(new RuntimeException('OpenAI Responses API error: HTTP ' . $response->status()));
            throw new RuntimeException('The AI service is temporarily unavailable. Please try again.');
        }

        $data = $response->json();
        $text = '';
        foreach (($data['output'] ?? []) as $item) {
            if (($item['type'] ?? null) !== 'message') continue;
            foreach (($item['content'] ?? []) as $part) {
                if (($part['type'] ?? null) === 'output_text') {
                    $text .= ($text === '' ? '' : "\n") . ($part['text'] ?? '');
                }
            }
        }

        if (trim($text) === '') {
            throw new RuntimeException('The AI service returned an empty response. Please try again.');
        }

        return [
            'text' => trim($text),
            'response_id' => $data['id'] ?? null,
            'usage' => $data['usage'] ?? null,
        ];
    }
}
