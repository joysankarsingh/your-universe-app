<?php

namespace App\Services;

use App\Models\TarotCard;
use App\Models\Reading;
use RuntimeException;

class TarotInterpreter
{
    public function __construct(
        private OpenAiResponses $openAi,
        private CosmicPrompt $prompt
    ) {}

    public function interpret(Reading $reading, array $profile): string
    {
        $cards = collect($reading->cards ?? []);
        if ($cards->isEmpty()) {
            throw new RuntimeException('This reading has no selected cards.');
        }

        $ids = $cards->pluck('card_id')->filter()->unique()->values();
        $catalogue = TarotCard::whereIn('id', $ids)->get()->keyBy('id');

        $cardContext = $cards->map(function ($selection) use ($catalogue) {
            $card = $catalogue->get($selection['card_id'] ?? null);
            if (!$card) return null;
            return [
                'card' => $card->name,
                'position' => $selection['position'] ?? 'Card',
                'orientation' => $selection['orientation'] ?? 'upright',
                'keywords' => ($selection['orientation'] ?? 'upright') === 'reversed'
                    ? $card->reversed_keywords : $card->upright_keywords,
            ];
        })->filter()->values()->all();

        if (count($cardContext) !== $cards->count()) {
            throw new RuntimeException('One or more selected Tarot cards are unavailable.');
        }

        $language = $reading->language ?: 'en';
        $instructions = $this->prompt->build($profile, $language);
        $userContent = "Create a thoughtful Tarot interpretation using ONLY these selected cards.\n"
            . "Reading type: {$reading->reading_type}\n"
            . "Topic: " . ($reading->topic ?? 'General') . "\n"
            . "Question: " . ($reading->question ?? 'No specific question') . "\n"
            . "Selected card data: " . json_encode($cardContext, JSON_UNESCAPED_UNICODE)
            . "\nExplain each position, then the overall pattern and one grounded reflection. "
            . "Do not claim certainty or facts about another person's private thoughts.";

        $result = $this->openAi->generate($instructions, [
            ['role' => 'user', 'content' => $userContent],
        ]);

        return $result['text'];
    }
}
