# Your Universe — Milestone 4: AI Cosmic Chat & Tarot Engine

This Laravel integration pack adds a server-side OpenAI Responses API service, engaging Cosmic Chat instructions, app-managed conversation memory, multilingual response guidance, Tarot interpretation scaffolding, and chat API integration.

## Why this design
- Uses the OpenAI **Responses API**, recommended by OpenAI for new projects.
- Keeps the API key on the server, never in Flutter.
- Keeps conversation history in your own database. Each request sends a bounded recent context; OpenAI `store` is set to false.
- Uses Tarot cards selected by your app/backend, not invented by the model.
- Adds a stable system instruction on every request.
- Persists assistant replies only after a successful API response.

Official references:
- Responses API overview: https://developers.openai.com/api/reference/responses/overview
- Migration guide: https://developers.openai.com/api/docs/guides/migrate-to-responses
- Create response: https://developers.openai.com/api/reference/resources/responses/methods/create

## Install
1. Start with the Laravel project from Milestone 3.
2. Copy these files into matching paths.
3. Add to `.env`:
```env
OPENAI_API_KEY=your_server_side_key
OPENAI_MODEL=gpt-5.5
OPENAI_TIMEOUT=45
COSMIC_CHAT_MAX_CONTEXT_MESSAGES=16
```
Choose a model available to your OpenAI project and test cost/latency before launch. The model name above is a configurable example, not a guarantee of account access.
4. Add `config/services.php` entries from `config_services_snippet.php`.
5. Ensure Laravel HTTP client is available (included in standard Laravel).
6. Run `php artisan config:clear`.

## New endpoints
- `POST /api/chat/threads/{thread}/messages` now stores the user message, generates an AI reply, stores it, and returns both.
- `POST /api/readings/{reading}/interpret` generates a Tarot interpretation using the cards already saved on the reading.

## Required database setup
Milestone 3 models/migrations must already be installed. Ensure `ChatMessage` and `Reading` models are present. Add the `interpret` route from the supplied route snippet.

## Engagement design
The system prompt guides the assistant to:
- Sound warm, emotionally attentive and natural rather than scripted.
- Use the user's chosen language (Bengali/Hindi/English).
- Refer to relevant profile/history without pretending to know missing facts.
- Ask at most one relevant follow-up question, only when useful.
- Avoid repetitive hooks, manipulative dependency, fear, certainty claims or pressure to buy.
- Treat Tarot as reflective/spiritual entertainment, not guaranteed prediction or professional advice.
- Escalate crisis or safety-sensitive disclosures appropriately.

## Important limitations
This is an integration pack, not a deployed/verified live service. It requires your own OpenAI API key, billing setup, Laravel environment and testing. No API call has been made from this pack. Credit deduction, Play Billing purchase verification, rate limiting, streaming, moderation review, analytics and production monitoring must be completed before public launch.
