// Merge this into the existing config/services.php array:
'openai' => [
    'key' => env('OPENAI_API_KEY'),
    'model' => env('OPENAI_MODEL', 'gpt-5.5'),
    'timeout' => (int) env('OPENAI_TIMEOUT', 45),
    'max_context_messages' => (int) env('COSMIC_CHAT_MAX_CONTEXT_MESSAGES', 16),
],
