<?php
// Merge these routes into the existing authenticated API route group.
use App\Http\Controllers\Api\CreditBalanceController;
use App\Http\Controllers\Api\VerifyCreditPurchaseController;
use Illuminate\Support\Facades\Route;

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/billing/google-play/verify-credit-purchase', VerifyCreditPurchaseController::class);
    Route::get('/credits', [CreditBalanceController::class, 'show']);
});
