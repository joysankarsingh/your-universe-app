# Release test checklist

- [ ] Purchase is verified against the exact Play package name and SKU.
- [ ] Pending purchase does not grant credits.
- [ ] Completed purchase grants the configured credit count.
- [ ] Repeated verification of the same token does not double-credit.
- [ ] Token already linked to a different account is rejected.
- [ ] Invalid token, wrong SKU and wrong package are rejected.
- [ ] Client cannot set amount, price, balance, expiry or Premium status.
- [ ] Insufficient balance blocks AI request.
- [ ] AI provider failure results in safe refund of reserved credits.
- [ ] Subscription renewal extends entitlement.
- [ ] Subscription cancellation preserves access only through valid paid-through period.
- [ ] Expiry, refund, revocation, grace period and account hold are handled.
- [ ] Restore purchases works after reinstall/device change.
- [ ] RTDN duplicate/out-of-order messages are idempotently processed.
- [ ] Support/admin audit trail exists; secrets and raw purchase tokens are never logged.
