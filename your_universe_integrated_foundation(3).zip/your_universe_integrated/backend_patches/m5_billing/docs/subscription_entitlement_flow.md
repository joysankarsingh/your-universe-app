# Subscription entitlement flow (implementation checklist)

For monthly/yearly Premium, the Android client sends only the purchase token to an authenticated backend endpoint.

Backend must:
1. Call `GooglePlayPurchaseVerifier::verifySubscription($token)`.
2. Match each returned `line_items[].product_id` against active `billing_products` rows where `type=subscription`.
3. Parse the returned expiry timestamp and determine whether the subscription is currently entitled, taking `subscription_state` into account.
4. Store the token hash and current entitlement state in a dedicated `user_subscriptions` table (recommended) with unique token hash.
5. Return only the server-calculated entitlement to the app.
6. Reconcile renewals, grace period, account hold, pause, cancellation and expiry via Google Play Real-time Developer Notifications (RTDN) and periodic server checks.

Do not simply set `premium=true` forever after the first successful purchase. Cancellation usually means the user retains access until the paid-through expiry date; refunds/revocations may require immediate entitlement removal. Exact handling must follow current Google Play Billing documentation.

This pack intentionally does not claim the subscription endpoint is finished: the product-to-entitlement mapping, RTDN Pub/Sub receiver, scheduled reconciliation, acknowledgement handling and restore flow remain to be integrated and tested.
