# Safe AI credit deduction pattern

Do not deduct credits on the Android device. On the server:
- Authenticate the user.
- Calculate the required credit cost from server-side configuration.
- In a DB transaction, lock the wallet and reserve/deduct credits using a unique request reference.
- Call the AI provider.
- On success, keep the charge and record usage metadata.
- On provider failure/timeout, issue an idempotent compensating refund transaction.
- Add per-user rate limits and abuse controls.

For longer calls, prefer a reservation table with `pending/completed/refunded` state and an expiry/reconciliation job. Never hold a database transaction open while waiting for a slow AI network request.
