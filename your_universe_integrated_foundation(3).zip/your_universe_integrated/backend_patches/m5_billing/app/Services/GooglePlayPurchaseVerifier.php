<?php

namespace App\Services;

use Google\Client as GoogleClient;
use Google\Service\AndroidPublisher;
use RuntimeException;

class GooglePlayPurchaseVerifier
{
    private function publisher(): AndroidPublisher
    {
        $credentialsPath = config('services.google_play.service_account_json');
        $packageName = config('services.google_play.package_name');

        if (!$credentialsPath || !is_file($credentialsPath) || !$packageName) {
            throw new RuntimeException('Google Play verification is not configured on the server.');
        }

        $client = new GoogleClient();
        $client->setAuthConfig($credentialsPath);
        $client->addScope(AndroidPublisher::ANDROIDPUBLISHER);

        return new AndroidPublisher($client);
    }

    /**
     * Verifies a one-time product purchase. Never trust product ID, price or state
     * supplied by the Android client without this server-side check.
     */
    public function verifyProduct(string $productId, string $purchaseToken): array
    {
        $api = $this->publisher();
        $package = config('services.google_play.package_name');

        $purchase = $api->purchases_products->get($package, $productId, $purchaseToken);

        // purchaseState 0 means purchased. Pending/cancelled purchases must not receive credits.
        if ((int) $purchase->getPurchaseState() !== 0) {
            throw new RuntimeException('Purchase is not in a completed state.');
        }

        return [
            'order_id' => $purchase->getOrderId(),
            'purchase_time_millis' => $purchase->getPurchaseTimeMillis(),
            'purchase_state' => (int) $purchase->getPurchaseState(),
            'acknowledgement_state' => $purchase->getAcknowledgementState(),
            'raw' => $purchase->toSimpleObject(),
        ];
    }

    /**
     * Subscription lookup pattern. Map the returned line item product ID and
     * expiryTime to your own entitlement rules; do not trust client expiry dates.
     */
    public function verifySubscription(string $purchaseToken): array
    {
        $api = $this->publisher();
        $package = config('services.google_play.package_name');

        $subscription = $api->purchases_subscriptionsv2->get($package, $purchaseToken);
        $items = $subscription->getLineItems() ?? [];
        $lineItems = [];

        foreach ($items as $item) {
            $lineItems[] = [
                'product_id' => $item->getProductId(),
                'expiry_time' => $item->getExpiryTime(),
            ];
        }

        return [
            'subscription_state' => $subscription->getSubscriptionState(),
            'latest_order_id' => $subscription->getLatestOrderId(),
            'line_items' => $lineItems,
            'raw' => $subscription->toSimpleObject(),
        ];
    }
}
