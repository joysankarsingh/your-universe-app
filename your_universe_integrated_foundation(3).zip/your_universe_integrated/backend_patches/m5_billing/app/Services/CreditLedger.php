<?php

namespace App\Services;

use App\Models\CreditTransaction;
use App\Models\CreditWallet;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class CreditLedger
{
    public function apply(int $userId, int $amount, string $type, string $reference, ?string $description = null, array $metadata = []): CreditTransaction
    {
        return DB::transaction(function () use ($userId, $amount, $type, $reference, $description, $metadata) {
            // Idempotency: same reference can never apply twice.
            $existing = CreditTransaction::where('reference', $reference)->first();
            if ($existing) {
                if ($existing->user_id !== $userId) {
                    throw new RuntimeException('Ledger reference conflict.');
                }
                return $existing;
            }

            $wallet = CreditWallet::firstOrCreate(
                ['user_id' => $userId],
                ['balance' => 0]
            );

            $wallet = CreditWallet::whereKey($wallet->id)->lockForUpdate()->firstOrFail();
            $newBalance = (int) $wallet->balance + $amount;

            if ($newBalance < 0) {
                throw new RuntimeException('Insufficient credits.');
            }

            $wallet->balance = $newBalance;
            $wallet->save();

            return CreditTransaction::create([
                'user_id' => $userId,
                'type' => $type,
                'amount' => $amount,
                'balance_after' => $newBalance,
                'reference' => $reference,
                'description' => $description,
                'metadata' => $metadata,
            ]);
        }, 3);
    }
}
