<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CreditTransaction;
use App\Models\CreditWallet;
use Illuminate\Http\Request;

class CreditBalanceController extends Controller
{
    public function show(Request $request)
    {
        $userId = $request->user()->id;
        $wallet = CreditWallet::firstOrCreate(['user_id' => $userId], ['balance' => 0]);

        return response()->json([
            'balance' => (int) $wallet->balance,
            'recent_transactions' => CreditTransaction::where('user_id', $userId)
                ->latest()->limit(20)->get([
                    'type', 'amount', 'balance_after', 'description', 'created_at'
                ]),
        ]);
    }
}
