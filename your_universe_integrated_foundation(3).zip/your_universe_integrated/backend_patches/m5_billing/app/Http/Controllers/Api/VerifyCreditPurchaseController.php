<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\BillingProduct;
use App\Models\PurchaseReceipt;
use App\Services\CreditLedger;
use App\Services\GooglePlayPurchaseVerifier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

class VerifyCreditPurchaseController extends Controller
{
    public function __invoke(
        Request $request,
        GooglePlayPurchaseVerifier $verifier,
        CreditLedger $ledger
    ) {
        $data = $request->validate([
            'product_id' => ['required', 'string', 'max:150'],
            'purchase_token' => ['required', 'string', 'max:5000'],
        ]);

        $product = BillingProduct::where('product_id', $data['product_id'])
            ->where('type', 'consumable_credit_pack')
            ->where('active', true)
            ->firstOrFail();

        try {
            $verified = $verifier->verifyProduct($product->product_id, $data['purchase_token']);
            $tokenHash = hash('sha256', $data['purchase_token']);

            $receipt = DB::transaction(function () use ($request, $product, $verified, $tokenHash, $data) {
                $existing = PurchaseReceipt::where('purchase_token_hash', $tokenHash)->first();
                if ($existing) {
                    if ($existing->user_id !== $request->user()->id) {
                        abort(409, 'This purchase token is already linked to another account.');
                    }
                    return $existing;
                }

                return PurchaseReceipt::create([
                    'user_id' => $request->user()->id,
                    'billing_product_id' => $product->id,
                    'platform' => 'google_play',
                    'purchase_token_hash' => $tokenHash,
                    'order_id' => $verified['order_id'] ?? null,
                    'purchase_state' => 'verified',
                    'purchased_at' => !empty($verified['purchase_time_millis'])
                        ? now()->setTimestamp((int) ($verified['purchase_time_millis'] / 1000))
                        : now(),
                    'verification_payload' => [
                        'purchase_state' => $verified['purchase_state'],
                        'acknowledgement_state' => $verified['acknowledgement_state'],
                    ],
                ]);
            });

            $ledger->apply(
                (int) $request->user()->id,
                (int) $product->credits,
                'purchase_credit',
                'play_purchase_' . $tokenHash,
                'Google Play credit pack: ' . $product->name,
                ['receipt_id' => $receipt->id, 'product_id' => $product->product_id]
            );

            return response()->json([
                'status' => 'verified',
                'credits_added' => (int) $product->credits,
                'balance' => (int) \App\Models\CreditWallet::where('user_id', $request->user()->id)->value('balance'),
            ]);
        } catch (Throwable $e) {
            report($e);
            return response()->json(['message' => 'Purchase verification failed. Please contact support if you were charged.'], 422);
        }
    }
}
