<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CreditWallet extends Model
{
    protected $fillable = ['user_id', 'balance'];
}
