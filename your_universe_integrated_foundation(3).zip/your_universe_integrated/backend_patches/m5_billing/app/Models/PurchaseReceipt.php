<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PurchaseReceipt extends Model
{
    protected $fillable = [
        'user_id', 'billing_product_id', 'platform', 'purchase_token_hash',
        'order_id', 'purchase_state', 'purchased_at', 'expires_at',
        'revoked_at', 'verification_payload',
    ];

    protected $casts = [
        'purchased_at' => 'datetime',
        'expires_at' => 'datetime',
        'revoked_at' => 'datetime',
        'verification_payload' => 'array',
    ];
}
