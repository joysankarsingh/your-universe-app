<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class BillingProduct extends Model
{
    protected $fillable = [
        'product_id', 'type', 'name', 'credits', 'price_minor',
        'currency', 'active', 'metadata',
    ];

    protected $casts = ['active' => 'boolean', 'metadata' => 'array'];
}
