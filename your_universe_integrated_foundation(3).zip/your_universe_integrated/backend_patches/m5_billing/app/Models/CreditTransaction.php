<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CreditTransaction extends Model
{
    protected $fillable = [
        'user_id', 'type', 'amount', 'balance_after',
        'reference', 'description', 'metadata',
    ];

    protected $casts = ['metadata' => 'array'];
}
