# Your Universe — Milestone 5: Payments & Credits (Laravel integration pack)

This is an integration pack, not a complete Laravel application and not a production-ready payment deployment.

## Included
- Product catalogue migration (credit packs and subscription SKUs)
- Purchase receipt ledger with unique token hash (idempotency)
- Credit wallet + immutable credit transaction ledger
- Server-side verification service skeleton for Google Play Billing
- API controller examples for verifying one-time credit-pack purchases
- Subscription entitlement endpoint pattern
- Route additions and setup checklist

## Important setup
1. Integrate this pack into the Laravel backend from Milestones 3–4.
2. Install/configure Google's PHP API client:
   `composer require google/apiclient:^2.0`
3. In Google Play Console, create in-app products/subscriptions and configure the Android Publisher API service account with the required Play Console permissions.
4. Store the service-account JSON securely outside source control. Set `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` to its absolute server-side path and `GOOGLE_PLAY_PACKAGE_NAME` to the exact Android application ID.
5. Set the real product IDs in `config/services.php` or your database. Product IDs in the seed example are placeholders.
6. Test using Play license testers and internal testing tracks. Verify purchase, acknowledgement, cancellation, refund, grace period, expiry, restore and duplicate callback cases.
7. Add scheduled reconciliation for subscriptions and refunds. A client callback is never the source of truth.

## Security and integration notes
- Never put Google service-account credentials or OpenAI API keys in the Android app.
- Never accept a client-supplied price, credit amount, subscription expiry, or `payment_success=true`.
- Verify the purchase token on your server with Google Play Developer API.
- A purchase token is stored only as a SHA-256 hash in the receipt table; do not log raw tokens.
- Credit grant is idempotent: a unique token hash and database transaction prevent duplicate crediting.
- This sample handles one-time credit packs as a starting point. Subscription verification is shown as a separate pattern and needs product-specific entitlement mapping.
- Refund/revocation handling and Real-time Developer Notifications (RTDN) must be implemented before public launch.
- Google Play Billing policy, service API versions, and regional availability can change. Check current official Google Play documentation before release.

## Integration assumptions
The existing backend has Laravel authentication and a `users` table. If Milestone 3's wallet tables already exist, reconcile migrations rather than creating duplicate tables. The code uses integer credits (not rupees/paise) and stores monetary amounts in minor currency units where applicable.
