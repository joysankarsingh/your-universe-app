// Merge this array entry into config/services.php (do not replace the whole file).
'google_play' => [
    'package_name' => env('GOOGLE_PLAY_PACKAGE_NAME'),
    'service_account_json' => env('GOOGLE_PLAY_SERVICE_ACCOUNT_JSON'),
],
