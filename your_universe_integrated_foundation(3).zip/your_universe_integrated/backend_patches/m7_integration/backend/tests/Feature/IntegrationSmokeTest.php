<?php

namespace Tests\Feature;

use Tests\TestCase;
use Illuminate\Foundation\Testing\RefreshDatabase;

class IntegrationSmokeTest extends TestCase
{
    use RefreshDatabase;

    public function test_health_endpoint_returns_ok_when_database_is_available(): void
    {
        $this->getJson('/api/v1/health')
            ->assertOk()
            ->assertJsonPath('status', 'ok');
    }

    // Add project-specific tests after merging the real models, migrations,
    // Sanctum configuration and controllers. Do not treat this template as
    // proof that payment, AI or wallet workflows have been tested.
}
