<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class HealthController extends Controller
{
    public function health()
    {
        try {
            DB::select('SELECT 1');
            return response()->json([
                'status' => 'ok',
                'database' => 'reachable',
                'timestamp' => now()->toIso8601String(),
            ]);
        } catch (\Throwable $e) {
            report($e);
            return response()->json([
                'status' => 'degraded',
                'database' => 'unavailable',
            ], 503);
        }
    }
}
