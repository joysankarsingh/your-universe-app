<?php
// Example only: merge into routes/api.php and align controller names with
// the actual integrated project. Do not register duplicate routes.

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\HealthController;

Route::prefix('v1')->group(function () {
    Route::get('/health', [HealthController::class, 'health']);

    // Add the existing auth/profile/tarot/chat/wallet/purchase/content routes here.
    // Keep protected routes inside auth:sanctum middleware.
    Route::middleware('auth:sanctum')->group(function () {
        Route::get('/me', function (\Illuminate\Http\Request $request) {
            return response()->json(['user' => $request->user()]);
        });
    });
});
