# Canonical API contract (proposed)

All endpoints use HTTPS. Protected routes require `Authorization: Bearer <Sanctum token>`.

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/v1/auth/register` | Create account |
| POST | `/api/v1/auth/login` | Login and return token |
| GET | `/api/v1/me` | Current user/profile |
| PUT | `/api/v1/profile/birth-details` | Update birth profile |
| GET | `/api/v1/tarot/cards` | Tarot card catalogue |
| POST | `/api/v1/readings` | Create reading from selected cards |
| POST | `/api/v1/chat/threads` | Create chat thread |
| GET | `/api/v1/chat/threads` | List own threads |
| POST | `/api/v1/chat/threads/{thread}/messages` | Send Cosmic Chat message |
| GET | `/api/v1/wallet` | Current wallet |
| GET | `/api/v1/wallet/transactions` | Ledger history |
| POST | `/api/v1/purchases/google/verify` | Verify Google Play purchase |
| GET | `/api/v1/content/daily?language=bn` | Published daily message |
| GET | `/api/v1/admin/dashboard` | Admin summary (admin only) |

## Chat request
```json
{
  "message": "আমার সম্পর্ক নিয়ে আজ কী ভাবা উচিত?",
  "language": "bn",
  "thread_id": 123,
  "feature": "cosmic_chat"
}
```

## Chat response
```json
{
  "thread_id": 123,
  "message": {
    "id": 456,
    "role": "assistant",
    "content": "..."
  },
  "wallet": {
    "balance": 18
  },
  "usage": {
    "input_tokens": 300,
    "output_tokens": 220
  }
}
```

Usage fields may be omitted from public responses if they are not needed by the app. Do not expose internal prompts, provider keys or private model metadata.

## Error contract
- `401`: unauthenticated
- `403`: authenticated but not entitled/authorized
- `404`: resource not found or not owned by user
- `409`: duplicate or conflicting purchase/action
- `422`: validation / insufficient credits
- `429`: rate limited
- `500/502`: internal/provider failure; no credit should be permanently charged for a failed generation

Never trust `thread_id` alone: verify thread ownership for every message request.
