# Target system architecture

```text
Flutter Android App
  | HTTPS + Sanctum bearer token
  v
Laravel API
  |-- Authentication + user profile
  |-- Tarot catalogue + readings
  |-- Cosmic Chat orchestration
  |     |-- load profile + consented conversation context
  |     |-- reserve credits transactionally
  |     |-- call AI provider (server-side key)
  |     |-- save response + usage log
  |     |-- finalize debit or release reservation on failure
  |
  |-- Google Play purchase verification
  |     |-- verify purchase token with Google Play Developer API
  |     |-- idempotent purchase ledger
  |     |-- grant entitlement / credits once
  |
  |-- Admin API (role-protected)
  |-- Daily content API (bn/hi/en)
  v
Database + encrypted backups
```

## Trust boundaries
- Flutter is an untrusted client. Never trust client-sent price, entitlement, credit balance, admin role or payment success.
- Laravel is the authority for user identity, credit balance, AI calls, purchase verification and access control.
- Google Play purchase tokens are verified server-side and stored securely; do not log raw tokens.
- AI provider keys stay in backend environment secrets.
- Admin operations are separately authorized and audited.

## Core user journey
1. User registers and completes profile.
2. User chooses preferred language.
3. User opens a Tarot feature or Cosmic Chat.
4. Backend checks entitlement and available credits.
5. Backend prepares contextual prompt from permitted profile/history.
6. Backend calls AI provider and records usage.
7. Backend returns a structured response and updated wallet balance.
8. For purchases, backend verifies store receipt/token before granting value.
