# Schema reconciliation before integration

The earlier milestone packs were created separately. Confirm the actual project schema and adapt code to one canonical naming convention.

| Domain | Expected entities | Required checks |
|---|---|---|
| Identity | users, personal_access_tokens | Sanctum trait, unique email/phone, status |
| Profile | birth_profiles | timezone, language, consent, nullable birth time/place |
| Tarot | tarot_cards, readings, reading_cards | Stable card IDs, upright/reversed, spread positions |
| Chat | chat_threads, chat_messages | thread ownership, role enum, metadata JSON |
| Wallet | credit_wallets, credit_transactions | integer balance, signed ledger amount, transaction type |
| Purchases | verified_purchases, subscriptions | unique store token/order ID, status, product ID, currency |
| AI | ai_usage_logs | provider/model, token counts, estimated cost, status |
| Admin | admin_audit_logs, universe_messages | actor, action, locale, publish state |

## Critical consistency rules
1. Store credit ledger entries as immutable records. Do not edit old transactions to correct balances.
2. Use DB transactions and row locks for wallet mutations.
3. Add unique constraints for Google Play purchase token/order identifiers.
4. Verify subscription state and expiry with Google Play; do not trust the app's local subscription flag.
5. Every chat thread and reading must be scoped to the authenticated user.
6. Avoid storing raw payment tokens in ordinary logs.
7. If birth details or chat history are stored, define retention, export and deletion behavior.
8. Keep monetary amounts in integer minor units (paise) or a fixed-precision decimal with explicit currency; never mix currencies in one total.
