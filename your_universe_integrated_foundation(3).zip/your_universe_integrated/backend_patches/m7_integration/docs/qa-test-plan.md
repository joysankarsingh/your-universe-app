# QA test plan

## Authentication
- Register with valid details; reject duplicate account.
- Login; reject incorrect credentials.
- Expired/revoked token returns 401.
- Suspended account cannot use protected features.

## Profile and localization
- Save and retrieve profile.
- Bengali, Hindi and English preference persists after restart.
- Missing birth time/place is handled without fabricated chart calculations.
- User can update/delete profile data according to policy.

## Tarot and chat
- Reading uses only selected card IDs returned by backend catalogue.
- User cannot read another user's thread or reading.
- Chat uses the requested language and handles empty/oversized input.
- Provider timeout/failure does not permanently consume credits.
- Retry does not duplicate a charge or duplicate a purchase.
- No claim of guaranteed prediction or certain knowledge of another person's private thoughts.

## Wallet and purchase
- Insufficient balance blocks generation.
- Concurrent requests cannot overdraw wallet.
- Invalid, cancelled, refunded or already-consumed purchase token grants no credits.
- Replayed valid token does not grant credits twice.
- Subscription expiry/revocation removes premium access according to verified store state.

## Admin
- Normal user receives 403 from admin endpoints.
- Admin cannot promote self to super-admin.
- Manual credit adjustment requires reason and creates audit log.
- Admin actions cannot expose raw chat contents or sensitive profile fields by default.

## Android release
- Test fresh install, update, logout/login, poor network and app resume.
- Test small and large screens, keyboard overlap and accessibility labels.
- Test Play Billing in license tester / internal testing track.
- Verify signed AAB, app icon, screenshots, privacy disclosures and Play Console declarations.
