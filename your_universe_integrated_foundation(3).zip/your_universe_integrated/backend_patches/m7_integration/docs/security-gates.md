# Security gates — launch blockers

- [ ] AI API key exists only in backend secrets; no key in Flutter assets, source or logs.
- [ ] All protected endpoints require authentication and object ownership checks.
- [ ] Admin routes require server-side role middleware; public registration cannot set admin flags.
- [ ] Google Play purchases are verified server-side and processed idempotently.
- [ ] Wallet mutations use database transactions, row locks and immutable ledger entries.
- [ ] AI credit is reserved/debited atomically; failed provider calls release/refund it.
- [ ] Rate limits exist for login, chat, reading generation and purchase verification.
- [ ] User input is validated and output is safely rendered (no unsafe HTML).
- [ ] Sensitive data is excluded from analytics and ordinary admin views.
- [ ] HTTPS, secure cookies/token handling, backups and restore test are in place.
- [ ] Privacy policy, terms, refund policy, consent and account deletion are available.
- [ ] Logging redacts tokens, API keys, birth details and private chat content.
- [ ] Dependency and server security updates are maintained.
- [ ] Independent security review is completed before handling real payments.
