# Production release checklist

## Backend
- [ ] Canonical Laravel app assembled; no duplicate migrations/routes.
- [ ] Production `.env` populated through secret manager, not committed.
- [ ] Database migrations run and rollback plan tested.
- [ ] Queue, scheduler, backups, monitoring and alerting configured.
- [ ] HTTPS and rate limiting enabled.
- [ ] Purchase verification + real-time subscription notifications tested.
- [ ] Wallet concurrency and idempotency tests pass.
- [ ] AI usage/cost records reconciled against provider billing.

## Android
- [ ] Correct application ID and versioning.
- [ ] API URL points to production HTTPS host.
- [ ] Secure token storage integrated.
- [ ] Play Billing products and subscription base plans configured.
- [ ] Internal testing with test accounts completed.
- [ ] Signed Android App Bundle generated securely.
- [ ] Privacy policy, Data Safety and content declarations reviewed.

## Go / no-go
Do not launch to paying users until all payment, wallet, privacy, security and recovery tests pass.
