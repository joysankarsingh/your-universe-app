# Your Universe — Milestone 7
## Integration Readiness, Security Hardening & QA Pack

### What this milestone does
This pack provides a structured integration layer and test plan for combining the Flutter client with the Laravel backend, AI chat, wallet/payment, admin APIs and multilingual content.

### Important scope boundary
The source ZIPs from Milestones 1–5 were not present in the active workspace when this pack was generated. Therefore this is **not** a merged, compiled, or runtime-tested app. It contains integration templates, API contracts, environment templates, security notes and QA tests. Existing model/table names must be reconciled before applying patches.

### Recommended integration order
1. Freeze one canonical Laravel project and one canonical Flutter project.
2. Merge backend migrations/models first; run migrations on a staging database.
3. Register Sanctum and admin middleware; confirm role checks.
4. Add AI provider config and server-side secrets; never place provider keys in Flutter.
5. Complete credit reservation/debit/refund as one server-controlled workflow.
6. Complete Google Play purchase verification and notification handling.
7. Connect Flutter API client and authentication token storage.
8. Run automated backend tests and physical Android device tests.
9. Fix all critical/high issues before production.
10. Build signed Android App Bundle and perform Play Console closed testing.

### Files
- `docs/system-architecture.md`: target integration map
- `docs/api-contract.md`: canonical endpoint proposal
- `docs/schema-reconciliation.md`: schema checks before merging
- `docs/security-gates.md`: launch-blocking security checks
- `docs/qa-test-plan.md`: manual and automated QA cases
- `backend/.env.example`: backend config placeholders
- `backend/routes/integration_routes.php`: route integration example
- `backend/app/Http/Controllers/Api/HealthController.php`: health endpoints
- `backend/tests/Feature/IntegrationSmokeTest.php`: smoke-test template
- `flutter/lib/core/config/app_config.dart`: API base URL config
- `flutter/lib/core/network/api_client.dart`: minimal authenticated API client template
- `flutter/lib/features/chat/chat_request_contract.dart`: chat request contract
- `release/release_checklist.md`: release readiness list

### No credentials needed in source
Do not send passwords, API keys, Google Play service account JSON, signing keystore or private tokens in chat. Add them directly to a secure deployment secret store.
