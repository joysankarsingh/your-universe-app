class AppConfig {
  AppConfig._();

  // Replace at build time with your HTTPS API host.
  // Never put AI provider or Google service-account secrets in this app.
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://api.example.com/api/v1',
  );
}
