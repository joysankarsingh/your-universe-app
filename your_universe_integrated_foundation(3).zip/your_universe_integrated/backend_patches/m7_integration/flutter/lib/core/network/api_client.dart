import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/app_config.dart';

class ApiClient {
  ApiClient({required this.readAccessToken});

  final Future<String?> Function() readAccessToken;

  Future<Map<String, dynamic>> getJson(String path) async {
    final token = await readAccessToken();
    final response = await http.get(
      Uri.parse('${AppConfig.apiBaseUrl}$path'),
      headers: _headers(token),
    );
    return _decode(response);
  }

  Future<Map<String, dynamic>> postJson(
    String path,
    Map<String, dynamic> body,
  ) async {
    final token = await readAccessToken();
    final response = await http.post(
      Uri.parse('${AppConfig.apiBaseUrl}$path'),
      headers: _headers(token),
      body: jsonEncode(body),
    );
    return _decode(response);
  }

  Map<String, String> _headers(String? token) => {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
  };

  Map<String, dynamic> _decode(http.Response response) {
    final decoded = response.body.isEmpty
        ? <String, dynamic>{}
        : jsonDecode(response.body) as Map<String, dynamic>;

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw ApiException(
        response.statusCode,
        decoded['message']?.toString() ?? 'Request failed',
        decoded,
      );
    }
    return decoded;
  }
}

class ApiException implements Exception {
  ApiException(this.statusCode, this.message, this.payload);
  final int statusCode;
  final String message;
  final Map<String, dynamic> payload;

  @override
  String toString() => 'ApiException($statusCode): $message';
}
