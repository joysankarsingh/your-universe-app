class ChatRequest {
  const ChatRequest({
    required this.message,
    required this.language,
    required this.threadId,
    this.feature = 'cosmic_chat',
  });

  final String message;
  final String language;
  final int threadId;
  final String feature;

  Map<String, dynamic> toJson() => {
    'message': message,
    'language': language,
    'thread_id': threadId,
    'feature': feature,
  };
}
