<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('tarot_cards', function (Blueprint $table) {
            $table->id();
            $table->string('slug')->unique();
            $table->string('name');
            $table->string('arcana', 20);
            $table->string('suit', 30)->nullable();
            $table->unsignedSmallInteger('sort_order')->unique();
            $table->text('upright_keywords')->nullable();
            $table->text('reversed_keywords')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('tarot_cards'); }
};
