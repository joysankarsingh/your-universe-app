<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('readings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('reading_type', 60);
            $table->string('topic', 60)->nullable();
            $table->string('question', 1000)->nullable();
            $table->string('language', 5)->default('en');
            $table->json('cards')->nullable();
            $table->longText('interpretation')->nullable();
            $table->string('status', 20)->default('draft');
            $table->timestamps();
            $table->index(['user_id', 'created_at']);
        });
    }
    public function down(): void { Schema::dropIfExists('readings'); }
};
