<?php

namespace Database\Seeders;

use App\Models\TarotCard;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class TarotCardSeeder extends Seeder
{
    public function run(): void
    {
        $major = [
            'The Fool','The Magician','The High Priestess','The Empress','The Emperor',
            'The Hierophant','The Lovers','The Chariot','Strength','The Hermit',
            'Wheel of Fortune','Justice','The Hanged Man','Death','Temperance',
            'The Devil','The Tower','The Star','The Moon','The Sun','Judgement','The World'
        ];
        $cards = [];
        foreach ($major as $i => $name) {
            $cards[] = ['name' => $name, 'arcana' => 'major', 'suit' => null, 'sort_order' => $i + 1];
        }
        $ranks = ['Ace','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten','Page','Knight','Queen','King'];
        foreach (['Wands','Cups','Swords','Pentacles'] as $suitIndex => $suit) {
            foreach ($ranks as $rankIndex => $rank) {
                $cards[] = [
                    'name' => "$rank of $suit", 'arcana' => 'minor', 'suit' => strtolower($suit),
                    'sort_order' => 23 + ($suitIndex * 14) + $rankIndex,
                ];
            }
        }
        foreach ($cards as $card) {
            TarotCard::updateOrCreate(
                ['sort_order' => $card['sort_order']],
                [
                    'slug' => Str::slug($card['name']),
                    'name' => $card['name'],
                    'arcana' => $card['arcana'],
                    'suit' => $card['suit'],
                    'sort_order' => $card['sort_order'],
                    'upright_keywords' => null,
                    'reversed_keywords' => null,
                    'is_active' => true,
                ]
            );
        }
    }
}
