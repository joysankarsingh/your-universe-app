<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\BirthProfileController;
use App\Http\Controllers\Api\TarotCardController;
use App\Http\Controllers\Api\ReadingController;
use App\Http\Controllers\Api\ChatController;
use App\Http\Controllers\Api\CreditController;

Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me', [AuthController::class, 'me']);

    Route::get('/birth-profile', [BirthProfileController::class, 'show']);
    Route::put('/birth-profile', [BirthProfileController::class, 'update']);

    Route::get('/tarot-cards', [TarotCardController::class, 'index']);

    Route::get('/readings', [ReadingController::class, 'index']);
    Route::post('/readings', [ReadingController::class, 'store']);
    Route::get('/readings/{reading}', [ReadingController::class, 'show']);

    Route::get('/chat/threads', [ChatController::class, 'threads']);
    Route::post('/chat/threads', [ChatController::class, 'createThread']);
    Route::get('/chat/threads/{thread}/messages', [ChatController::class, 'messages']);
    Route::post('/chat/threads/{thread}/messages', [ChatController::class, 'storeMessage']);

    Route::get('/credits', [CreditController::class, 'show']);
});
