# Your Universe — Backend Milestone 3

Laravel backend integration pack for the Your Universe Android Tarot app.

## Included
- Sanctum-protected API route structure
- Birth profile, tarot card catalogue, reading history, chat threads/messages
- Credit wallet and immutable credit transaction ledger
- Admin-ready role field on users
- Starter Tarot deck seeder (78 card names)
- API controllers with validation and ownership checks

## Important
This is an integration pack, not a complete installed Laravel application. Start with a fresh Laravel application (Laravel 11/12 recommended), install Sanctum, then copy these files into the matching locations. Configure a supported production database and run migrations.

## Setup
```bash
composer create-project laravel/laravel your-universe-api
cd your-universe-api
php artisan install:api
```
If `install:api` does not install Sanctum in your Laravel version:
```bash
composer require laravel/sanctum
php artisan vendor:publish --provider="Laravel\\Sanctum\\SanctumServiceProvider"
php artisan migrate
```

Copy the contents of this pack into the Laravel project, preserving folder paths, then run:
```bash
php artisan migrate
php artisan db:seed --class=TarotCardSeeder
php artisan serve
```

## API endpoints
All endpoints below are prefixed with `/api`.

### Authentication
- `POST /register` — name, email, password, password_confirmation
- `POST /login` — email, password; returns Sanctum token
- `POST /logout` — authenticated; revokes current token
- `GET /me` — authenticated profile

### User data
- `GET /birth-profile`
- `PUT /birth-profile`
- `GET /tarot-cards`
- `GET /readings`
- `POST /readings`
- `GET /readings/{reading}`

### Chat
- `GET /chat/threads`
- `POST /chat/threads`
- `GET /chat/threads/{thread}/messages`
- `POST /chat/threads/{thread}/messages`

### Credits
- `GET /credits`

## Security and production work still required
- Add email verification, password reset, rate limits and abuse monitoring.
- Add Google Play purchase verification on the server before granting credits or subscriptions. Never trust a client-supplied “payment successful” flag.
- Add OpenAI calls through a server-side service; keep API keys out of the Android app.
- Add privacy policy, consent, retention/deletion workflows and regional legal review before international launch.
- Add automated tests, logging, backups, monitoring and deployment configuration.
- Do not store card numbers or payment credentials in this application.

The included chat endpoint stores messages only. It does **not** call OpenAI yet. The reading endpoint stores user-created reading records; it does **not** claim to provide a validated AI tarot interpretation yet.
