<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Reading;
use Illuminate\Http\Request;

class ReadingController extends Controller
{
    public function index(Request $request)
    {
        return response()->json(Reading::where('user_id', $request->user()->id)->latest()->paginate(20));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'reading_type' => ['required','string','max:60'],
            'topic' => ['nullable','string','max:60'],
            'question' => ['nullable','string','max:1000'],
            'language' => ['nullable','in:bn,hi,en'],
            'cards' => ['nullable','array','max:10'],
            'cards.*.card_id' => ['required_with:cards','integer','exists:tarot_cards,id'],
            'cards.*.position' => ['nullable','string','max:60'],
            'cards.*.orientation' => ['nullable','in:upright,reversed'],
        ]);
        $reading = Reading::create($data + [
            'user_id' => $request->user()->id,
            'language' => $data['language'] ?? 'en',
            'status' => 'pending_interpretation',
        ]);
        return response()->json($reading, 201);
    }

    public function show(Request $request, Reading $reading)
    {
        abort_unless($reading->user_id === $request->user()->id, 404);
        return response()->json($reading);
    }
}
