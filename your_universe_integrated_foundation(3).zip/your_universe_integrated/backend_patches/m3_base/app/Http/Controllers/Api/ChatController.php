<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ChatThread;
use Illuminate\Http\Request;

class ChatController extends Controller
{
    public function threads(Request $request)
    {
        return response()->json(ChatThread::where('user_id', $request->user()->id)->latest()->paginate(20));
    }

    public function createThread(Request $request)
    {
        $data = $request->validate(['title' => ['nullable','string','max:120'], 'language' => ['nullable','in:bn,hi,en']]);
        $thread = ChatThread::create($data + ['user_id' => $request->user()->id, 'language' => $data['language'] ?? 'en']);
        return response()->json($thread, 201);
    }

    public function messages(Request $request, ChatThread $thread)
    {
        abort_unless($thread->user_id === $request->user()->id, 404);
        return response()->json($thread->messages()->latest()->paginate(50));
    }

    public function storeMessage(Request $request, ChatThread $thread)
    {
        abort_unless($thread->user_id === $request->user()->id, 404);
        $data = $request->validate(['content' => ['required','string','max:12000']]);
        $message = $thread->messages()->create(['role' => 'user', 'content' => $data['content']]);
        // AI response is intentionally not generated in this milestone.
        return response()->json(['message' => $message, 'ai_status' => 'not_connected'], 201);
    }
}
