<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\TarotCard;
use Illuminate\Http\Request;

class TarotCardController extends Controller
{
    public function index(Request $request)
    {
        $query = TarotCard::where('is_active', true)->orderBy('sort_order');
        if ($request->filled('arcana')) $query->where('arcana', $request->string('arcana'));
        if ($request->filled('suit')) $query->where('suit', $request->string('suit'));
        return response()->json($query->paginate(100));
    }
}
