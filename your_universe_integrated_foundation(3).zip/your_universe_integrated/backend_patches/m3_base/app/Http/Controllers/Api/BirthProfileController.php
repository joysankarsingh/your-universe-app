<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BirthProfileController extends Controller
{
    public function show(Request $request)
    {
        return response()->json($request->user()->birthProfile);
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'birth_date' => ['nullable','date','before_or_equal:today'],
            'birth_time' => ['nullable','date_format:H:i'],
            'birth_place' => ['nullable','string','max:190'],
            'timezone' => ['nullable','timezone'],
            'pronouns' => ['nullable','string','max:30'],
        ]);
        $profile = $request->user()->birthProfile()->updateOrCreate(
            ['user_id' => $request->user()->id], $data
        );
        return response()->json($profile);
    }
}
