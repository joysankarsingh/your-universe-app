<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\CreditWallet;
use Illuminate\Http\Request;

class CreditController extends Controller
{
    public function show(Request $request)
    {
        $wallet = CreditWallet::firstOrCreate(['user_id' => $request->user()->id], ['balance' => 0]);
        return response()->json([
            'balance' => $wallet->balance,
            'transactions' => $wallet->transactions()->latest()->limit(30)->get(),
        ]);
    }
}
