<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TarotCard extends Model
{
    protected $fillable = ['slug','name','arcana','suit','sort_order','upright_keywords','reversed_keywords','is_active'];
    protected $casts = ['is_active' => 'boolean'];
}
