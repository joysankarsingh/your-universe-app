<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CreditTransaction extends Model
{
    protected $fillable = ['wallet_id','type','amount','reference','description','metadata'];
    protected $casts = ['metadata' => 'array'];
    public function wallet(): BelongsTo { return $this->belongsTo(CreditWallet::class, 'wallet_id'); }
}
