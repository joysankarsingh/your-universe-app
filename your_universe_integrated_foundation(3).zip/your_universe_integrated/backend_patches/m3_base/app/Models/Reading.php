<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Reading extends Model
{
    protected $fillable = ['user_id','reading_type','topic','question','language','cards','interpretation','status'];
    protected $casts = ['cards' => 'array'];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
