<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class BirthProfile extends Model
{
    protected $fillable = ['user_id', 'birth_date', 'birth_time', 'birth_place', 'timezone', 'pronouns'];
    protected $casts = ['birth_date' => 'date'];

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
}
