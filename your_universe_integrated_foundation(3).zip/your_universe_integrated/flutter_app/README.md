# Your Universe — Integrated Flutter Foundation

This folder combines the Milestone 8 Flutter shell with the Milestone 1 onboarding flow.

## Included
- Splash and welcome screens
- Registration and birth-profile prototype screens
- Purple/gold theme
- Home dashboard with seven feature entry points
- Profile screen and language selector
- API client and chat request/response contracts

## Run on Windows 11
1. Install Flutter SDK and Android Studio.
2. Open this folder in VS Code or Android Studio.
3. In the terminal run `flutter doctor`.
4. Run `flutter pub get`.
5. Connect an Android phone with USB debugging enabled, or start an emulator.
6. Run `flutter run`.

## Important status
This is an assembled UI foundation, not a production-ready app. Registration and birth details currently remain local prototype screens; they are not saved to a backend. Feature screens are placeholders. Authentication, secure token storage, live AI, real Tarot spreads, wallet, Google Play Billing, server deployment and admin access remain to be integrated and tested. The default API URL is intentionally a placeholder.

Do not put OpenAI keys, Google Play service-account files, passwords or signing keys in Flutter or in chat.
