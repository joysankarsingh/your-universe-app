class ChatSendRequest {
  const ChatSendRequest({
    required this.message,
    required this.language,
    required this.threadId,
  });

  final String message;
  final String language;
  final int threadId;

  Map<String, dynamic> toJson() => {
    'message': message,
    'language': language,
    'thread_id': threadId,
    'feature': 'cosmic_chat',
  };
}

class ChatSendResponse {
  const ChatSendResponse({
    required this.threadId,
    required this.messageId,
    required this.content,
    required this.walletBalance,
  });

  final int threadId;
  final int messageId;
  final String content;
  final int walletBalance;

  factory ChatSendResponse.fromJson(Map<String, dynamic> json) {
    final message = json['message'] as Map<String, dynamic>;
    final wallet = json['wallet'] as Map<String, dynamic>;
    return ChatSendResponse(
      threadId: json['thread_id'] as int,
      messageId: message['id'] as int,
      content: message['content'] as String,
      walletBalance: wallet['balance'] as int,
    );
  }
}
