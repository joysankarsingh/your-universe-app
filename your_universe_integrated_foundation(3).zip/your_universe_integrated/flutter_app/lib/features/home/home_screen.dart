import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../shared/feature_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  static const _features = [
    _Feature('Daily Universe Message', 'A personal message for today', Icons.wb_twilight),
    _Feature('Love & Relationship Tarot', 'Explore relationship themes', Icons.favorite_border),
    _Feature('Interactive Tarot Reading', 'Choose cards for your question', Icons.style_outlined),
    _Feature('Hidden Secrets & Family Energy', 'Reflect on family and social dynamics', Icons.visibility_outlined),
    _Feature('Spiritual Guidance & Learning', 'Learn tarot and reflective practices', Icons.auto_stories_outlined),
    _Feature('AI Cosmic Chat', 'A thoughtful spiritual companion', Icons.forum_outlined),
    _Feature('AI Tarot Reader', 'An AI-guided card interpretation', Icons.catching_pokemon_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 22, 20, 10),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'YOUR UNIVERSE',
                    style: TextStyle(
                      color: AppTheme.goldLight,
                      letterSpacing: 3,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Text('Your journey, your universe.',
                    style: Theme.of(context).textTheme.headlineSmall),
                  const SizedBox(height: 6),
                  const Text('A space for reflection, clarity and self-discovery.'),
                  const SizedBox(height: 20),
                  _DailyCard(onTap: () => _open(context, _features.first)),
                  const SizedBox(height: 24),
                  Text('Explore your universe',
                    style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
            sliver: SliverGrid(
              delegate: SliverChildBuilderDelegate(
                (context, index) => _FeatureCard(
                  feature: _features[index],
                  onTap: () => _open(context, _features[index]),
                ),
                childCount: _features.length,
              ),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _open(BuildContext context, _Feature feature) {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => FeatureScreen(title: feature.title, description: feature.description),
    ));
  }
}

class _Feature {
  const _Feature(this.title, this.description, this.icon);
  final String title;
  final String description;
  final IconData icon;
}

class _DailyCard extends StatelessWidget {
  const _DailyCard({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF38245F), Color(0xFF1B1238), Color(0xFF17102F)],
          ),
          border: Border.all(color: AppTheme.gold.withValues(alpha: .65)),
        ),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(Icons.wb_twilight, color: AppTheme.goldLight, size: 30),
            SizedBox(height: 12),
            Text('TODAY’S UNIVERSE MESSAGE',
              style: TextStyle(color: AppTheme.goldLight, letterSpacing: 1.2, fontSize: 11)),
            SizedBox(height: 7),
            Text('Make space for the clarity you are ready to receive.',
              style: TextStyle(color: AppTheme.text, fontSize: 18, fontWeight: FontWeight.w600)),
            SizedBox(height: 8),
            Text('Tap to explore today’s reflection  →',
              style: TextStyle(color: AppTheme.muted, fontSize: 12)),
          ],
        ),
      ),
    );
  }
}

class _FeatureCard extends StatelessWidget {
  const _FeatureCard({required this.feature, required this.onTap});
  final _Feature feature;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(feature.icon, color: AppTheme.goldLight, size: 27),
              const SizedBox(height: 10),
              Text(feature.title,
                style: const TextStyle(color: AppTheme.text, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(feature.description,
                maxLines: 2, overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppTheme.muted, fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }
}
