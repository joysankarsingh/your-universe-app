import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  String _language = 'বাংলা';

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text('Your Profile', style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 18),
          const _ProfileField(label: 'Name', value: 'Not connected yet'),
          const _ProfileField(label: 'Date of Birth', value: 'Not connected yet'),
          const _ProfileField(label: 'Birth Time', value: 'Optional'),
          const _ProfileField(label: 'Birth Place', value: 'Optional'),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Expanded(child: Text('App Language',
                    style: TextStyle(color: AppTheme.text, fontWeight: FontWeight.w600))),
                  DropdownButton<String>(
                    value: _language,
                    dropdownColor: AppTheme.surface,
                    items: const [
                      DropdownMenuItem(value: 'বাংলা', child: Text('বাংলা')),
                      DropdownMenuItem(value: 'हिन्दी', child: Text('हिन्दी')),
                      DropdownMenuItem(value: 'English', child: Text('English')),
                    ],
                    onChanged: (value) {
                      if (value != null) setState(() => _language = value);
                    },
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Card(
            child: ListTile(
              leading: Icon(Icons.account_balance_wallet_outlined, color: AppTheme.goldLight),
              title: Text('Wallet'),
              subtitle: Text('Will display server-verified balance after API integration'),
            ),
          ),
          const Card(
            child: ListTile(
              leading: Icon(Icons.workspace_premium_outlined, color: AppTheme.goldLight),
              title: Text('Premium Membership'),
              subtitle: Text('Subscription status will be verified by the backend'),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileField extends StatelessWidget {
  const _ProfileField({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(label, style: const TextStyle(color: AppTheme.text)),
        subtitle: Text(value),
        trailing: const Icon(Icons.chevron_right, color: AppTheme.gold),
      ),
    );
  }
}
