import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';
import 'onboarding/splash_screen.dart';

class YourUniverseApp extends StatelessWidget {
  const YourUniverseApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Your Universe',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: const SplashScreen(),
    );
  }
}
