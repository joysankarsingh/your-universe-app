import 'package:flutter/material.dart';
import 'onboarding_theme.dart';
import 'birth_profile_screen.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _hidePassword = true;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  void _continue() {
    if (!_formKey.currentState!.validate()) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => BirthProfileScreen(
      name: _name.text.trim(), email: _email.text.trim(),
    )));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create your account')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
            children: [
              const Text('Your journey starts here', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w600, color: AppColors.goldLight)),
              const SizedBox(height: 8),
              const Text('Create an account to keep your readings and personal guidance together.', style: TextStyle(color: AppColors.muted, height: 1.45)),
              const SizedBox(height: 28),
              TextFormField(controller: _name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Full name', prefixIcon: Icon(Icons.person_outline)), validator: (v) => (v == null || v.trim().isEmpty) ? 'Please enter your name' : null),
              const SizedBox(height: 16),
              TextFormField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.mail_outline)), validator: (v) => (v == null || !RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim())) ? 'Enter a valid email address' : null),
              const SizedBox(height: 16),
              TextFormField(controller: _password, obscureText: _hidePassword, decoration: InputDecoration(labelText: 'Password', prefixIcon: const Icon(Icons.lock_outline), suffixIcon: IconButton(icon: Icon(_hidePassword ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => _hidePassword = !_hidePassword))), validator: (v) => (v == null || v.length < 8) ? 'Use at least 8 characters' : null),
              const SizedBox(height: 24),
              ElevatedButton(onPressed: _continue, child: const Text('Continue')),
              const SizedBox(height: 14),
              const Text('Prototype only: secure account creation, email verification and OTP will be connected to the backend before production.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 11, height: 1.4)),
            ],
          ),
        ),
      ),
    );
  }
}
