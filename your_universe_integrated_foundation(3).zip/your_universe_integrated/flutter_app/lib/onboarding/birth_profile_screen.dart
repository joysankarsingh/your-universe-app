import 'package:flutter/material.dart';
import 'onboarding_theme.dart';
import '../features/shell/app_shell.dart';

class BirthProfileScreen extends StatefulWidget {
  final String name;
  final String email;
  const BirthProfileScreen({super.key, required this.name, required this.email});

  @override
  State<BirthProfileScreen> createState() => _BirthProfileScreenState();
}

class _BirthProfileScreenState extends State<BirthProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _place = TextEditingController();
  DateTime? _birthDate;
  TimeOfDay? _birthTime;
  String _language = 'English';

  @override
  void dispose() {
    _place.dispose();
    super.dispose();
  }

  Future<void> _chooseDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(context: context, initialDate: DateTime(1995), firstDate: DateTime(1920), lastDate: now);
    if (picked != null) setState(() => _birthDate = picked);
  }

  Future<void> _chooseTime() async {
    final picked = await showTimePicker(context: context, initialTime: const TimeOfDay(hour: 12, minute: 0));
    if (picked != null) setState(() => _birthTime = picked);
  }

  void _finish() {
    if (!_formKey.currentState!.validate()) return;
    if (_birthDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please select your date of birth.')));
      return;
    }
    Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const AppShell()), (route) => false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Your birth profile')),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.fromLTRB(22, 16, 22, 28),
            children: [
              const Text('Personalize your guidance', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w600, color: AppColors.goldLight)),
              const SizedBox(height: 8),
              const Text('Birth details are optional for general Tarot readings, but can help personalize astrology-related features. You can edit them later.', style: TextStyle(color: AppColors.muted, height: 1.45)),
              const SizedBox(height: 22),
              _infoTile(Icons.person_outline, 'Name', widget.name),
              const SizedBox(height: 12),
              _infoTile(Icons.email_outlined, 'Email', widget.email),
              const SizedBox(height: 16),
              OutlinedButton.icon(onPressed: _chooseDate, icon: const Icon(Icons.calendar_month), label: Text(_birthDate == null ? 'Select date of birth' : '${_birthDate!.day}/${_birthDate!.month}/${_birthDate!.year}'), style: OutlinedButton.styleFrom(foregroundColor: AppColors.goldLight, minimumSize: const Size.fromHeight(52), side: BorderSide(color: AppColors.gold.withOpacity(.6)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
              const SizedBox(height: 12),
              OutlinedButton.icon(onPressed: _chooseTime, icon: const Icon(Icons.schedule), label: Text(_birthTime == null ? 'Select birth time (optional)' : _birthTime!.format(context)), style: OutlinedButton.styleFrom(foregroundColor: AppColors.goldLight, minimumSize: const Size.fromHeight(52), side: BorderSide(color: AppColors.gold.withOpacity(.6)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)))),
              const SizedBox(height: 16),
              TextFormField(controller: _place, decoration: const InputDecoration(labelText: 'Birth place (city, country)', prefixIcon: Icon(Icons.location_on_outlined)), validator: (v) => (v == null || v.trim().isEmpty) ? 'Enter your birth place or skip this step later' : null),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(value: _language, decoration: const InputDecoration(labelText: 'Preferred language', prefixIcon: Icon(Icons.language)), items: const ['English', 'বাংলা', 'हिन्दी'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => _language = v ?? 'English')),
              const SizedBox(height: 24),
              ElevatedButton(onPressed: _finish, child: const Text('Save profile & continue')),
              const SizedBox(height: 12),
              TextButton(onPressed: () => Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const AppShell()), (route) => false), child: const Text('I will add these details later', style: TextStyle(color: AppColors.muted))),
            ],
          ),
        ),
      ),
    );
  }

  Widget _infoTile(IconData icon, String title, String value) => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.gold.withOpacity(.25))),
        child: Row(children: [Icon(icon, color: AppColors.gold), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(color: AppColors.muted, fontSize: 11)), const SizedBox(height: 3), Text(value, style: const TextStyle(color: AppColors.text, fontWeight: FontWeight.w500))]))]),
      );
}
