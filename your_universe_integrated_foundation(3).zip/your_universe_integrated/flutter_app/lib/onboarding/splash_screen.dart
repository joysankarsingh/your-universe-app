import 'package:flutter/material.dart';
import 'onboarding_theme.dart';
import 'welcome_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const WelcomeScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: RadialGradient(
            center: Alignment(0, -.25),
            radius: 1.1,
            colors: [Color(0xFF49216D), AppColors.background],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 104,
                height: 104,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: AppColors.gold, width: 1.5),
                  boxShadow: [BoxShadow(color: AppColors.gold.withOpacity(.25), blurRadius: 28)],
                ),
                child: const Icon(Icons.auto_awesome, color: AppColors.goldLight, size: 54),
              ),
              const SizedBox(height: 22),
              const Text('Your Universe', style: TextStyle(fontSize: 32, color: AppColors.goldLight, fontWeight: FontWeight.w600)),
              const SizedBox(height: 8),
              const Text('Tarot • Astrology • Spiritual Guidance', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 12, letterSpacing: .5)),
            ],
          ),
        ),
      ),
    );
  }
}
