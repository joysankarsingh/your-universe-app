import 'package:flutter/material.dart';
import 'onboarding_theme.dart';
import 'registration_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 30, 24, 24),
          child: Column(
            children: [
              const Spacer(),
              Container(
                height: 190,
                width: 190,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const RadialGradient(colors: [Color(0xFF7140A1), AppColors.surface, AppColors.background]),
                  border: Border.all(color: AppColors.gold.withOpacity(.8)),
                  boxShadow: [BoxShadow(color: AppColors.purple.withOpacity(.4), blurRadius: 35)],
                ),
                child: const Icon(Icons.nights_stay, size: 92, color: AppColors.goldLight),
              ),
              const SizedBox(height: 34),
              const Text('Discover your path', textAlign: TextAlign.center, style: TextStyle(fontSize: 29, fontWeight: FontWeight.w600, color: AppColors.goldLight)),
              const SizedBox(height: 12),
              const Text('Explore Tarot guidance, understand your energy and connect with your personal Universe guide.', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, height: 1.5, fontSize: 15)),
              const Spacer(),
              ElevatedButton(
                onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegistrationScreen())),
                child: const Text('Begin your journey'),
              ),
              const SizedBox(height: 14),
              const Text('Your journey. Your questions. Your Universe.', style: TextStyle(color: AppColors.muted, fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }
}
