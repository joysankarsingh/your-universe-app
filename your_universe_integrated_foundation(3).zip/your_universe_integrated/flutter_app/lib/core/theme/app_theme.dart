import 'package:flutter/material.dart';

class AppTheme {
  static const Color background = Color(0xFF100A25);
  static const Color surface = Color(0xFF1B1238);
  static const Color surfaceAlt = Color(0xFF26194A);
  static const Color gold = Color(0xFFD8B56A);
  static const Color goldLight = Color(0xFFF3D99B);
  static const Color text = Color(0xFFF8F1E4);
  static const Color muted = Color(0xFFB8ADC9);

  static ThemeData get dark {
    final scheme = ColorScheme.fromSeed(
      seedColor: gold,
      brightness: Brightness.dark,
      surface: surface,
    );
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      scaffoldBackgroundColor: background,
      colorScheme: scheme,
      appBarTheme: const AppBarTheme(
        backgroundColor: background,
        foregroundColor: text,
        centerTitle: true,
        elevation: 0,
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 0,
        shape: RoundedRectangleBorder(
          side: const BorderSide(color: Color(0x665C4728)),
          borderRadius: BorderRadius.circular(18),
        ),
      ),
      textTheme: const TextTheme(
        headlineSmall: TextStyle(
          color: text, fontWeight: FontWeight.w700,
        ),
        titleMedium: TextStyle(
          color: text, fontWeight: FontWeight.w600,
        ),
        bodyMedium: TextStyle(color: muted, height: 1.45),
      ),
      navigationBarTheme: const NavigationBarThemeData(
        backgroundColor: surface,
        indicatorColor: surfaceAlt,
        labelTextStyle: WidgetStatePropertyAll(
          TextStyle(color: text, fontSize: 11),
        ),
      ),
    );
  }
}
